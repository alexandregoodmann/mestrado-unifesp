# ---------------------------------------------------------------------------------------
# ALUNO: ALEXANDRE FERREIRA E SILVA
# 
# Rodar o comando abaixo como exemplo
# python3 Alexandre_Ferreira_e_Silva_ Atividade_01.py '/home/alexandre/Documents/PI/imgs/Lenna.png' 50 100 70 150
# ---------------------------------------------------------------------------------------

import cv2 as cv
import sys
import numpy as np
import matplotlib.pyplot as plt 

# valida imagem
img = cv.imread(sys.argv[1]);
assert img is not None, 'Arquivo nao encontrado'

# valida os valores de input para retangulo
y0 = int(sys.argv[2])
yn = int(sys.argv[3])
x0 = int(sys.argv[4])
xn = int(sys.argv[5])

if (y0 < 0 or yn < 0 or x0 < 0 or xn < 0):
    print('Os valores para o retangulo precisam ser maiores que zero')
    exit()

# ------------------------------------------------------------------------------------
# converte a imagem para escala de cinza e abre
# ------------------------------------------------------------------------------------
altura, largura, canais = img.shape
img2 = img
for y in range(altura):
    for x in range(largura):
        pixel = img[x,y]
        r, g, b = pixel
        cinza = int(0.2989 * r + 0.5870 * g + 0.1140 * b)
        img2[x,y] = (cinza, cinza, cinza)

cv.imshow('Imagem colorida em escala de cinza', img2)
cv.waitKey(0)
cv.destroyAllWindows()

# ------------------------------------------------------------------------------------
# aplica o retangulo colorido na imagem em tons de cinza
# ------------------------------------------------------------------------------------
largura_retangulo = xn - x0
altura_retangulo = yn - y0
print('area retangulo', largura_retangulo * altura_retangulo)

#aplicar um retangula na imagem
img2[y0, x0:xn] = [255, 0, 0]
img2[yn, x0:xn] = [0, 255, 0]
img2[y0:yn, x0] = [0, 0, 255]
img2[y0:yn, xn] = [255, 255, 255]

cv.imshow('Source Image', img2)
cv.waitKey(0)
cv.destroyAllWindows()